<?php
session_start();
require_once "../views/header.php";
?>
<div class="about-box">
    <h2>About St. Alphonsus Primary School</h2>
    <p>
        St. Alphonsus Primary School is a community-focused primary school
        committed to providing a safe, inclusive, and supportive learning
        environment. The school portal helps staff efficiently manage
        academic records, attendance, and communication.
    </p>
</div>

<div class="header">Dashboard</div>

<div class="card-container">

    <a href="../app/teacher/index.php">
        <div class="card">
            <h3>Teachers</h3>
            <span>Manage staff records</span>
        </div>
    </a>

    <a href="../app/classes/index.php">
        <div class="card">
            <h3>Classes</h3>
            <span>Manage school classes</span>
        </div>
    </a>

    <a href="../app/pupil/index.php">
        <div class="card">
            <h3>Pupils</h3>
            <span>View pupil records</span>
        </div>
    </a>

    <a href="../app/parent/index.php">
        <div class="card">
            <h3>Parents</h3>
            <span>Manage parent info</span>
        </div>
    </a>

    <a href="../app/attendance/index.php">
        <div class="card">
            <h3>Attendance</h3>
            <span>Pupil attendance</span>
        </div>
    </a>

    <a href="../app/library_book/index.php">
        <div class="card">
            <h3>Library</h3>
            <span>Book records</span>
        </div>
    </a>

</div>

<?php require_once "../views/footer.php"; ?>
