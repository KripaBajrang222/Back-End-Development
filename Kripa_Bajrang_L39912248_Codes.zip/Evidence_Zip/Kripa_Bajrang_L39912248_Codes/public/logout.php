<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logged Out</title>
    <link rel="stylesheet" href="/school_portal/assets/css/style.css">
</head>
<body>

<div class="main-content">
    <div class="header">Logged Out</div>

    <p>You have been logged out successfully.</p>
    <p>Please click below to log in again.</p>

    <br>
    <a class="btn" href="/school_portal/public/login.php">Go to Login</a>
</div>

</body>
</html>
