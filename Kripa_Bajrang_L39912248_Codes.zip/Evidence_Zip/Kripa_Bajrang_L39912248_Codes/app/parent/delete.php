<?php
session_start();
require_once "../../views/header.php";
$id = (int)$_GET['id'];
?>

<div class="header">Delete Parent</div>

<p>Are you sure you want to delete this parent?</p>

<a class="btn" href="destroy.php?id=<?= $id ?>">Yes, Delete</a>
<a class="btn" href="index.php">Cancel</a>

<?php require_once "../../views/footer.php"; ?>
