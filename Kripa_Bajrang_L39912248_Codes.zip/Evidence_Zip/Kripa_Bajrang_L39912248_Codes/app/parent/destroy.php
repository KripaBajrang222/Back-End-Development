<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];
$conn->query("DELETE FROM parent WHERE id=$id");

header("Location: index.php");
exit;
