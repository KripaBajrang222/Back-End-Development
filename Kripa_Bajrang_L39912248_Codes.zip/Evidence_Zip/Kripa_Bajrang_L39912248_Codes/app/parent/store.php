<?php
session_start();
require_once "../../config/db.php";

$sql = "INSERT INTO parent 
(first_name, last_name, email, phone, address_line1, address_line2, city, postcode)
VALUES (
    '{$_POST['first_name']}',
    '{$_POST['last_name']}',
    '{$_POST['email']}',
    '{$_POST['phone']}',
    '{$_POST['address_line1']}',
    '{$_POST['address_line2']}',
    '{$_POST['city']}',
    '{$_POST['postcode']}'
)";

$conn->query($sql);
header("Location: index.php");
exit;
