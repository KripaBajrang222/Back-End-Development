<?php
session_start();
require_once "../../views/header.php";
?>

<div class="header">Add Parent</div>

<form action="store.php" method="post">
    <label>First Name</label>
    <input type="text" name="first_name" required>

    <label>Last Name</label>
    <input type="text" name="last_name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Phone</label>
    <input type="text" name="phone">

    <label>Address Line 1</label>
    <input type="text" name="address_line1">

    <label>Address Line 2</label>
    <input type="text" name="address_line2">

    <label>City</label>
    <input type="text" name="city">

    <label>Postcode</label>
    <input type="text" name="postcode">

    <button type="submit">Save</button>
</form>

<?php require_once "../../views/footer.php"; ?>
