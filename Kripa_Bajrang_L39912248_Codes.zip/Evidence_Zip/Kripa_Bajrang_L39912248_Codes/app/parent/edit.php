<?php
session_start();
require_once "../../config/db.php";
require_once "../../views/header.php";

$id = (int)$_GET['id'];
$row = $conn->query("SELECT * FROM parent WHERE id=$id")->fetch_assoc();
?>

<div class="header">Edit Parent</div>

<form action="update.php?id=<?= $id ?>" method="post">
    <label>First Name</label>
    <input type="text" name="first_name" value="<?= $row['first_name'] ?>" required>

    <label>Last Name</label>
    <input type="text" name="last_name" value="<?= $row['last_name'] ?>" required>

    <label>Email</label>
    <input type="email" name="email" value="<?= $row['email'] ?>" required>

    <label>Phone</label>
    <input type="text" name="phone" value="<?= $row['phone'] ?>">

    <label>Address Line 1</label>
    <input type="text" name="address_line1" value="<?= $row['address_line1'] ?>">

    <label>Address Line 2</label>
    <input type="text" name="address_line2" value="<?= $row['address_line2'] ?>">

    <label>City</label>
    <input type="text" name="city" value="<?= $row['city'] ?>">

    <label>Postcode</label>
    <input type="text" name="postcode" value="<?= $row['postcode'] ?>">

    <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
