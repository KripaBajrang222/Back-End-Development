<?php
session_start();
require_once "../../config/db.php";
require_once "../../views/header.php";

$result = $conn->query("SELECT * FROM parent ORDER BY first_name");
?>

<div class="header">Parents</div>

<a class="btn" href="create.php">+ Add Parent</a><br><br>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['first_name'] . " " . $row['last_name'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['phone'] ?></td>
            <td>
                <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
            </td>
        </tr>
    <?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
