<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];

$sql = "UPDATE parent SET
first_name='{$_POST['first_name']}',
last_name='{$_POST['last_name']}',
email='{$_POST['email']}',
phone='{$_POST['phone']}',
address_line1='{$_POST['address_line1']}',
address_line2='{$_POST['address_line2']}',
city='{$_POST['city']}',
postcode='{$_POST['postcode']}'
WHERE id=$id";

$conn->query($sql);
header("Location: index.php");
exit;
