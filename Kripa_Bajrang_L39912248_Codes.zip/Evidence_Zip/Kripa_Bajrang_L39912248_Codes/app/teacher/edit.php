<?php


require_once "../../config/db.php";
require_once "../../views/header.php";

$id = $_GET['id'];
$teacher = $conn->query("SELECT * FROM teacher WHERE id = $id")->fetch_assoc();
?>

<div class="header">Edit Teacher</div>

<form action="update.php" method="post">
    <input type="hidden" name="id" value="<?= $teacher['id'] ?>">

    <label>First Name</label>
    <input type="text" name="first_name" value="<?= $teacher['first_name'] ?>" required>

    <label>Last Name</label>
    <input type="text" name="last_name" value="<?= $teacher['last_name'] ?>" required>

    <label>Phone</label>
    <input type="text" name="phone" value="<?= $teacher['phone'] ?>">

    <label>Annual Salary</label>
    <input type="number" name="annual_salary" value="<?= $teacher['annual_salary'] ?>" required>

    <label>Background Check Date</label>
    <input type="date" name="background_check_date" value="<?= $teacher['background_check_date'] ?>" required>

    <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
