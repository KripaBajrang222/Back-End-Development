<?php

require_once "../../config/db.php";

$id = $_POST['id'];

$sql = "
UPDATE teacher SET
first_name = '{$_POST['first_name']}',
last_name = '{$_POST['last_name']}',
phone = '{$_POST['phone']}',
annual_salary = '{$_POST['annual_salary']}',
background_check_date = '{$_POST['background_check_date']}'
WHERE id = $id
";

$conn->query($sql);

header("Location: index.php");
exit;
