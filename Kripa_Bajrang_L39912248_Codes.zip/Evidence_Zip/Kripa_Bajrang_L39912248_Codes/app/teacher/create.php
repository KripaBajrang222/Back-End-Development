<?php

require_once "../../views/header.php";
?>

<div class="header">Add Teacher</div>

<form action="store.php" method="post">

    <label>First Name</label>
    <input type="text" name="first_name" required>

    <label>Last Name</label>
    <input type="text" name="last_name" required>

    <label>Phone</label>
    <input type="text" name="phone">

    <label>Annual Salary</label>
    <input type="number" name="annual_salary" step="0.01" required>

    <label>Background Check Date</label>
    <input type="date" name="background_check_date" required>

    <button type="submit">Save Teacher</button>
</form>

<?php require_once "../../views/footer.php"; ?>
