<?php
require_once "../../config/db.php";



$sql = "
SELECT 
    id,
    CONCAT(first_name, ' ', last_name) AS name,
    phone,
    annual_salary,
    background_check_date
FROM teacher
WHERE first_name IS NOT NULL
  AND first_name != ''
ORDER BY id ASC
";

$result = $conn->query($sql);

require_once "../../views/header.php";
?>

<div class="header">Teachers</div>

<a class="btn" href="create.php">+ Add New Teacher</a>
<br><br>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Teacher Name</th>
            <th>Phone</th>
            <th>Annual Salary (£)</th>
            <th>Background Check Date</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= number_format((float)$row['annual_salary'], 2) ?></td>
                <td><?= htmlspecialchars($row['background_check_date']) ?></td>
                <td>
                    <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                    <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="6">No teachers found.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

<?php require_once "../../views/footer.php"; ?>
