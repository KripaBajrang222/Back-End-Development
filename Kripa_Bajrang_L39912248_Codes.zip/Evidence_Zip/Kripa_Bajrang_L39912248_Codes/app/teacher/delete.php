<?php

require_once "../../config/db.php";
require_once "../../views/header.php";

$id = $_GET['id'];
$t = $conn->query("SELECT * FROM teacher WHERE id=$id")->fetch_assoc();
?>

<div class="header">Delete Teacher</div>

<p>Are you sure you want to delete <b><?= $t['first_name']." ".$t['last_name'] ?></b>?</p>

<a class="btn" href="destroy.php?id=<?= $id ?>">Yes, Delete</a>
<a class="btn" href="index.php">Cancel</a>

<?php require_once "../../views/footer.php"; ?>
