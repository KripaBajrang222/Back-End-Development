<?php


require_once "../../config/db.php";

$first_name = $_POST['first_name'];
$last_name  = $_POST['last_name'];
$phone      = $_POST['phone'];
$salary     = $_POST['annual_salary'];
$bg_date    = $_POST['background_check_date'];

$sql = "
INSERT INTO teacher 
(first_name, last_name, phone, annual_salary, background_check_date)
VALUES 
('$first_name', '$last_name', '$phone', '$salary', '$bg_date')
";

$conn->query($sql);

header("Location: index.php");
exit;
