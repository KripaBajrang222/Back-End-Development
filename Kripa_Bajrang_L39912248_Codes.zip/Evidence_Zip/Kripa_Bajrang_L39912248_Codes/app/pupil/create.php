<?php
session_start();
require_once "../../config/db.php";

$classes = $conn->query("SELECT * FROM class");

require_once "../../views/header.php";
?>

<div class="header">Add Pupil</div>

<form action="store.php" method="post">

    <label>First Name</label>
    <input type="text" name="first_name" required>

    <label>Last Name</label>
    <input type="text" name="last_name" required>

    <label>Date of Birth</label>
    <input type="date" name="dob" required>

    <label>Address Line 1</label>
    <input type="text" name="address_line1" required>

    <label>Address Line 2</label>
    <input type="text" name="address_line2">

    <label>City</label>
    <input type="text" name="city">

    <label>Postcode</label>
    <input type="text" name="postcode">

    <label>Medical Notes</label>
    <textarea name="medical_notes"></textarea>

    <label>Class</label>
    <select name="class_id">
        <option value="">-- Select Class --</option>
        <?php while ($c = $classes->fetch_assoc()) { ?>
            <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
        <?php } ?>
    </select>

    <button type="submit">Save</button>
</form>

<?php require_once "../../views/footer.php"; ?>
