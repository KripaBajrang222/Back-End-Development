<?php
session_start();
require_once "../../config/db.php";

$sql = "
SELECT p.*, c.name AS class_name
FROM pupil p
LEFT JOIN class c ON p.class_id = c.id
";
$result = $conn->query($sql);

require_once "../../views/header.php";
?>

<div class="header">Pupils</div>

<a class="btn" href="create.php">+ Add New Pupil</a><br><br>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>DOB</th>
        <th>City</th>
        <th>Class</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['first_name'] . " " . $row['last_name'] ?></td>
            <td><?= $row['dob'] ?></td>
            <td><?= $row['city'] ?></td>
            <td><?= $row['class_name'] ?? 'Not Assigned' ?></td>
            <td>
                <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
            </td>
        </tr>
    <?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
