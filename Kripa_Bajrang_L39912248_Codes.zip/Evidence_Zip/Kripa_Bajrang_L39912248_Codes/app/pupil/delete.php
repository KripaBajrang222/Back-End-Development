<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];
$pupil = $conn->query("SELECT * FROM pupil WHERE id=$id")->fetch_assoc();

require_once "../../views/header.php";
?>

<div class="header">Delete Pupil</div>

<p>Are you sure you want to delete:</p>
<b><?= $pupil['first_name'] . " " . $pupil['last_name'] ?></b><br><br>

<a class="btn" href="destroy.php?id=<?= $id ?>">Yes, Delete</a>
<a class="btn" href="index.php">Cancel</a>

<?php require_once "../../views/footer.php"; ?>
