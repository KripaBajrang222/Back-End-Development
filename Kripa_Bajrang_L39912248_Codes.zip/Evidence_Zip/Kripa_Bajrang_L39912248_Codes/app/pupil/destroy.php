<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];
$conn->query("DELETE FROM pupil WHERE id=$id");

header("Location: index.php");
exit;
