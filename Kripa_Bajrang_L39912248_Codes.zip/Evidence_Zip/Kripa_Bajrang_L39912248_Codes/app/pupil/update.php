<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];

$sql = "UPDATE pupil SET
first_name='{$_POST['first_name']}',
last_name='{$_POST['last_name']}',
dob='{$_POST['dob']}',
address_line1='{$_POST['address_line1']}',
address_line2='{$_POST['address_line2']}',
city='{$_POST['city']}',
postcode='{$_POST['postcode']}',
medical_notes='{$_POST['medical_notes']}',
class_id=" . ($_POST['class_id'] ? $_POST['class_id'] : "NULL") . "
WHERE id=$id";

$conn->query($sql);
header("Location: index.php");
exit;
