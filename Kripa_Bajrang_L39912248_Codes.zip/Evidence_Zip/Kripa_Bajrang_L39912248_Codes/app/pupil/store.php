<?php
session_start();
require_once "../../config/db.php";

$first = $_POST['first_name'];
$last = $_POST['last_name'];
$dob = $_POST['dob'];
$addr1 = $_POST['address_line1'];
$addr2 = $_POST['address_line2'];
$city = $_POST['city'];
$postcode = $_POST['postcode'];
$medical = $_POST['medical_notes'];
$class = $_POST['class_id'] ?: NULL;

$sql = "INSERT INTO pupil 
(first_name, last_name, dob, address_line1, address_line2, city, postcode, medical_notes, class_id)
VALUES (
'$first', '$last', '$dob', '$addr1', '$addr2', '$city', '$postcode', '$medical',
" . ($class ? $class : "NULL") . "
)";

$conn->query($sql);
header("Location: index.php");
exit;
