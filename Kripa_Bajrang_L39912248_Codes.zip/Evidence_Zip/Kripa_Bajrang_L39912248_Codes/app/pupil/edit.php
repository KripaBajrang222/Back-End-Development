<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];
$pupil = $conn->query("SELECT * FROM pupil WHERE id=$id")->fetch_assoc();
$classes = $conn->query("SELECT * FROM class");

require_once "../../views/header.php";
?>

<div class="header">Edit Pupil</div>

<form action="update.php?id=<?= $id ?>" method="post">

    <label>First Name</label>
    <input type="text" name="first_name" value="<?= $pupil['first_name'] ?>" required>

    <label>Last Name</label>
    <input type="text" name="last_name" value="<?= $pupil['last_name'] ?>" required>

    <label>Date of Birth</label>
    <input type="date" name="dob" value="<?= $pupil['dob'] ?>" required>

    <label>Address Line 1</label>
    <input type="text" name="address_line1" value="<?= $pupil['address_line1'] ?>" required>

    <label>Address Line 2</label>
    <input type="text" name="address_line2" value="<?= $pupil['address_line2'] ?>">

    <label>City</label>
    <input type="text" name="city" value="<?= $pupil['city'] ?>">

    <label>Postcode</label>
    <input type="text" name="postcode" value="<?= $pupil['postcode'] ?>">

    <label>Medical Notes</label>
    <textarea name="medical_notes"><?= $pupil['medical_notes'] ?></textarea>

    <label>Class</label>
    <select name="class_id">
        <option value="">-- Select Class --</option>
        <?php while ($c = $classes->fetch_assoc()) { ?>
            <option value="<?= $c['id'] ?>" <?= $pupil['class_id'] == $c['id'] ? 'selected' : '' ?>>
                <?= $c['name'] ?>
            </option>
        <?php } ?>
    </select>

    <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
