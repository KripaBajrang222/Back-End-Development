<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];

$attendance = $conn->query("SELECT * FROM attendance WHERE id=$id")->fetch_assoc();
$pupils = $conn->query("SELECT id, first_name, last_name FROM pupil");

require_once "../../views/header.php";
?>

<div class="header">Edit Attendance</div>

<form action="update.php?id=<?= $id ?>" method="post">

  <label>Pupil</label>
  <select name="pupil_id" required>
    <?php while ($p = $pupils->fetch_assoc()) { ?>
      <option value="<?= $p['id'] ?>"
        <?= $attendance['pupil_id'] == $p['id'] ? 'selected' : '' ?>>
        <?= htmlspecialchars($p['first_name'] . " " . $p['last_name']) ?>
      </option>
    <?php } ?>
  </select>

  <label>Date</label>
  <input type="date" name="date" value="<?= $attendance['date'] ?>" required>

  <label>Status</label>
  <select name="status">
    <option value="Present" <?= $attendance['status']=='Present'?'selected':'' ?>>Present</option>
    <option value="Absent" <?= $attendance['status']=='Absent'?'selected':'' ?>>Absent</option>
    <option value="Late" <?= $attendance['status']=='Late'?'selected':'' ?>>Late</option>
  </select>

  <label>Notes</label>
  <input type="text" name="notes" value="<?= htmlspecialchars($attendance['notes']) ?>">

  <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
