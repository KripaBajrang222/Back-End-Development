<?php
session_start();
require_once "../../config/db.php";

$sql = "
SELECT a.id, a.date, a.status, a.notes,
       CONCAT(p.first_name, ' ', p.last_name) AS pupil_name
FROM attendance a
JOIN pupil p ON a.pupil_id = p.id
ORDER BY a.date DESC
";
$result = $conn->query($sql);

require_once "../../views/header.php";
?>

<div class="header">Attendance</div>

<a class="btn" href="create.php">+ Add Attendance</a><br><br>

<table>
  <tr>
    <th>ID</th>
    <th>Pupil</th>
    <th>Date</th>
    <th>Status</th>
    <th>Notes</th>
    <th>Actions</th>
  </tr>

  <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['pupil_name']) ?></td>
      <td><?= $row['date'] ?></td>
      <td><?= htmlspecialchars($row['status']) ?></td>
      <td><?= htmlspecialchars($row['notes']) ?></td>
      <td>
        <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
        <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
      </td>
    </tr>
  <?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
