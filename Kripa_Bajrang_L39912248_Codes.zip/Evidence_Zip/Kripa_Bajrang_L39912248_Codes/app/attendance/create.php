<?php
session_start();
require_once "../../config/db.php";

$pupils = $conn->query("SELECT id, first_name, last_name FROM pupil ORDER BY first_name");

require_once "../../views/header.php";
?>

<div class="header">Add Attendance</div>

<form action="store.php" method="post">

  <label>Pupil</label>
  <select name="pupil_id" required>
    <option value="">-- Select Pupil --</option>
    <?php while ($p = $pupils->fetch_assoc()) { ?>
      <option value="<?= $p['id'] ?>">
        <?= htmlspecialchars($p['first_name'] . " " . $p['last_name']) ?>
      </option>
    <?php } ?>
  </select>

  <label>Date</label>
  <input type="date" name="date" required>

  <label>Status</label>
  <select name="status" required>
    <option value="Present">Present</option>
    <option value="Absent">Absent</option>
    <option value="Late">Late</option>
  </select>

  <label>Notes</label>
  <input type="text" name="notes">

  <button type="submit">Save</button>
</form>

<?php require_once "../../views/footer.php"; ?>
