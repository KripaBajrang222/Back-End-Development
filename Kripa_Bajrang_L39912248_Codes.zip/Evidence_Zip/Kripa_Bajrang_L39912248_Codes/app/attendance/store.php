<?php
session_start();
require_once "../../config/db.php";

$pupil_id = (int)$_POST['pupil_id'];
$date = $_POST['date'];
$status = $_POST['status'];
$notes = $_POST['notes'] ?? '';

$sql = "INSERT INTO attendance (pupil_id, date, status, notes)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("isss", $pupil_id, $date, $status, $notes);
$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
