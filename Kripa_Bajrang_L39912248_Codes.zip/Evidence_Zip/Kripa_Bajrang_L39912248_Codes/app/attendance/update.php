<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];
$pupil_id = (int)$_POST['pupil_id'];
$date = $_POST['date'];
$status = $_POST['status'];
$notes = $_POST['notes'] ?? '';

$sql = "UPDATE attendance
        SET pupil_id=?, date=?, status=?, notes=?
        WHERE id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("isssi", $pupil_id, $date, $status, $notes, $id);
$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
