<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare("DELETE FROM attendance WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
