<?php
session_start();
require_once "../../config/db.php";

$id = (int)$_GET['id'];

$row = $conn->query("
SELECT a.id, a.date,
       CONCAT(p.first_name, ' ', p.last_name) AS pupil_name
FROM attendance a
JOIN pupil p ON a.pupil_id = p.id
WHERE a.id=$id
")->fetch_assoc();

require_once "../../views/header.php";
?>

<div class="header">Delete Attendance</div>

<p>Are you sure you want to delete attendance for:</p>
<p><strong><?= htmlspecialchars($row['pupil_name']) ?> on <?= $row['date'] ?></strong></p>
<br>

<a class="btn" href="destroy.php?id=<?= $id ?>">Yes, Delete</a>
<a class="btn" href="index.php">Cancel</a>

<?php require_once "../../views/footer.php"; ?>
