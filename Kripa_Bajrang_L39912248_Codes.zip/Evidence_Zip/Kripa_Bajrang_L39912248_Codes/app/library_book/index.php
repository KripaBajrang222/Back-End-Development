<?php
session_start();
require_once "../../config/db.php";

$sql = "SELECT * FROM library_book";
$result = $conn->query($sql);

require_once "../../views/header.php";
?>

<div class="header">Library Books</div>

<a class="btn" href="create.php">+ Add New Book</a><br><br>

<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>ISBN</th>
        <th>Available Copies</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['title'] ?></td>
            <td><?= $row['author'] ?></td>
            <td><?= $row['isbn'] ?></td>
            <td><?= $row['available_copies'] ?></td>
            <td>
                <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
            </td>
        </tr>
    <?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
