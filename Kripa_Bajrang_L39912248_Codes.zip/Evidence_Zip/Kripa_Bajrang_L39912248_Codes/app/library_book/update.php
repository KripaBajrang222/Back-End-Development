<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];

$sql = "UPDATE library_book SET
title='{$_POST['title']}',
author='{$_POST['author']}',
isbn='{$_POST['isbn']}',
available_copies='{$_POST['available_copies']}'
WHERE id=$id";

$conn->query($sql);
header("Location: index.php");
exit;
