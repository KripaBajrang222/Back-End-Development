<?php
session_start();
require_once "../../views/header.php";
?>

<div class="header">Add Library Book</div>

<form method="post" action="store.php">

    <label>Title</label>
    <input type="text" name="title" required>

    <label>Author</label>
    <input type="text" name="author" required>

    <label>ISBN</label>
    <input type="text" name="isbn" required>

    <label>Available Copies</label>
    <input type="number" name="available_copies" required>

    <br><br>
    <button type="submit">Save Book</button>
</form>

<?php require_once "../../views/footer.php"; ?>
