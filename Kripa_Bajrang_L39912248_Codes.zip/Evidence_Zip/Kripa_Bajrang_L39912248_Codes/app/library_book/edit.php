<?php
session_start();
require_once "../../config/db.php";

$id = $_GET['id'];
$book = $conn->query("SELECT * FROM library_book WHERE id=$id")->fetch_assoc();

require_once "../../views/header.php";
?>

<div class="header">Edit Book</div>

<form action="update.php?id=<?= $id ?>" method="post">

    <label>Title</label>
    <input type="text" name="title" value="<?= $book['title'] ?>" required>

    <label>Author</label>
    <input type="text" name="author" value="<?= $book['author'] ?>" required>

    <label>ISBN</label>
    <input type="text" name="isbn" value="<?= $book['isbn'] ?>" required>

    <label>Available Copies</label>
    <input type="number" name="available_copies" value="<?= $book['available_copies'] ?>" required>

    <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
