<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../../config/db.php";

$title = $_POST['title'];
$author = $_POST['author'];
$isbn = $_POST['isbn'];
$available_copies = $_POST['available_copies'];


$check = $conn->query("SELECT id FROM library_book WHERE isbn='$isbn'");

if ($check->num_rows > 0) {
    echo "<script>
        alert('This ISBN already exists in the library.');
        window.location.href='create.php';
    </script>";
    exit;
}


$sql = "INSERT INTO library_book 
(title, author, isbn, available_copies)
VALUES 
('$title', '$author', '$isbn', '$available_copies')";

$conn->query($sql);

header("Location: index.php");
exit;
