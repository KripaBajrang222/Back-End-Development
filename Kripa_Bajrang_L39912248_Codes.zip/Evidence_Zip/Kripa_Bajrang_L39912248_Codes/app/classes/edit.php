<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: index.php"); exit; }

$class = $conn->query("SELECT * FROM class WHERE id=$id")->fetch_assoc();
if (!$class) { header("Location: index.php"); exit; }

$teachers = $conn->query("SELECT id, first_name, last_name FROM teacher ORDER BY first_name");

require_once "../../views/header.php";
?>

<div class="header">Edit Class</div>

<form action="update.php?id=<?= $id ?>" method="post">
  <label>Class Name</label>
  <input type="text" name="name" value="<?= htmlspecialchars($class['name']) ?>" required>

  <label>Capacity</label>
  <input type="number" name="capacity" value="<?= (int)$class['capacity'] ?>" required min="1">

  <label>Teacher (optional)</label>
  <select name="teacher_id">
    <option value="">-- Not Assigned --</option>
    <?php while ($t = $teachers->fetch_assoc()) { 
        $selected = ($class['teacher_id'] == $t['id']) ? 'selected' : '';
    ?>
      <option value="<?= $t['id'] ?>" <?= $selected ?>>
        <?= htmlspecialchars($t['first_name'] . " " . $t['last_name']) ?>
      </option>
    <?php } ?>
  </select>

  <button type="submit">Update</button>
</form>

<?php require_once "../../views/footer.php"; ?>
