<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$name = trim($_POST['name'] ?? '');
$capacity = (int)($_POST['capacity'] ?? 0);
$teacher_id = $_POST['teacher_id'] ?? '';

if ($name === '' || $capacity <= 0) {
    header("Location: create.php");
    exit;
}

if ($teacher_id === '') {
    $stmt = $conn->prepare("INSERT INTO class (name, capacity, teacher_id) VALUES (?, ?, NULL)");
    $stmt->bind_param("si", $name, $capacity);
} else {
    $teacher_id = (int)$teacher_id;
    $stmt = $conn->prepare("INSERT INTO class (name, capacity, teacher_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $name, $capacity, $teacher_id);
}

$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
