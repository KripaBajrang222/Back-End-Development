<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: index.php"); exit; }

$name = trim($_POST['name'] ?? '');
$capacity = (int)($_POST['capacity'] ?? 0);
$teacher_id = $_POST['teacher_id'] ?? '';

if ($name === '' || $capacity <= 0) {
    header("Location: edit.php?id=$id");
    exit;
}

if ($teacher_id === '') {
    $stmt = $conn->prepare("UPDATE class SET name=?, capacity=?, teacher_id=NULL WHERE id=?");
    $stmt->bind_param("sii", $name, $capacity, $id);
} else {
    $teacher_id = (int)$teacher_id;
    $stmt = $conn->prepare("UPDATE class SET name=?, capacity=?, teacher_id=? WHERE id=?");
    $stmt->bind_param("siii", $name, $capacity, $teacher_id, $id);
}

$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
