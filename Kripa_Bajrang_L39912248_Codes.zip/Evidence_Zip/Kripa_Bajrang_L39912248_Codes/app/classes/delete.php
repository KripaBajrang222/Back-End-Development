<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: index.php"); exit; }

$class = $conn->query("SELECT id, name FROM class WHERE id=$id")->fetch_assoc();
if (!$class) { header("Location: index.php"); exit; }

require_once "../../views/header.php";
?>

<div class="header">Delete Class</div>

<p>Are you sure you want to delete:</p>
<p><strong><?= htmlspecialchars($class['name']) ?></strong></p>
<br>

<a class="btn" href="destroy.php?id=<?= $id ?>">Yes, Delete</a>
<a class="btn" href="index.php">Cancel</a>

<?php require_once "../../views/footer.php"; ?>
