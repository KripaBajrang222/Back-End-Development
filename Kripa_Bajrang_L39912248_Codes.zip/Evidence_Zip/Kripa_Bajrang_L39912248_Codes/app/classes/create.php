<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$teachers = $conn->query("SELECT id, first_name, last_name FROM teacher ORDER BY first_name");

require_once "../../views/header.php";
?>

<div class="header">Add Class</div>

<form action="store.php" method="post">
  <label>Class Name</label>
  <input type="text" name="name" required>

  <label>Capacity</label>
  <input type="number" name="capacity" required min="1">

  <label>Teacher (optional)</label>
  <select name="teacher_id">
    <option value="">-- Not Assigned --</option>
    <?php while ($t = $teachers->fetch_assoc()) { ?>
      <option value="<?= $t['id'] ?>">
        <?= htmlspecialchars($t['first_name'] . " " . $t['last_name']) ?>
      </option>
    <?php } ?>
  </select>

  <button type="submit">Save</button>
</form>

<?php require_once "../../views/footer.php"; ?>
