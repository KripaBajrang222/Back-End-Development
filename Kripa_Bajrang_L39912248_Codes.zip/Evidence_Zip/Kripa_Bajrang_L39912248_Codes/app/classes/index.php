<?php
require_once "../../config/auth.php";
require_once "../../config/db.php";

$sql = "
SELECT c.id, c.name, c.capacity, c.teacher_id,
       CONCAT(t.first_name, ' ', t.last_name) AS teacher_name
FROM class c
LEFT JOIN teacher t ON c.teacher_id = t.id
ORDER BY c.id DESC
";
$result = $conn->query($sql);

require_once "../../views/header.php";
?>

<div class="header">Classes</div>

<a class="btn" href="create.php">+ Add New Class</a><br><br>

<table>
  <tr>
    <th>ID</th>
    <th>Class Name</th>
    <th>Capacity</th>
    <th>Teacher</th>
    <th>Actions</th>
  </tr>

  <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= $row['capacity'] ?></td>
      <td><?= $row['teacher_name'] ? htmlspecialchars($row['teacher_name']) : "Not Assigned" ?></td>
      <td>
        <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
        <a class="btn" href="delete.php?id=<?= $row['id'] ?>">Delete</a>
      </td>
    </tr>
  <?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
