<?php
session_start();
require_once "../../config/db.php";

$pupil_id = (int) $_GET['pupil_id'];

$conn->query("DELETE FROM pupil_parent WHERE pupil_id = $pupil_id");

header("Location: index.php");
exit;
