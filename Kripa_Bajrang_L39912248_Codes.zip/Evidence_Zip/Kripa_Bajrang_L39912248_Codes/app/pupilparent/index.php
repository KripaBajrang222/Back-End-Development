<?php
require_once "../../config/db.php";
require_once "../../views/header.php";

$sql = "
SELECT 
    pp.pupil_id,
    pp.parent_id,
    pp.relationship_type,
    CONCAT(p.first_name,' ',p.last_name) AS pupil_name,
    CONCAT(pa.first_name,' ',pa.last_name) AS parent_name
FROM pupil_parent pp
JOIN pupil p ON pp.pupil_id = p.id
JOIN parent pa ON pp.parent_id = pa.id
ORDER BY pupil_name
";

$result = $conn->query($sql);
?>

<div class="header">Pupil – Parent Links</div>

<a class="btn" href="add.php">+ Link Parent</a>
<br><br>

<table>
<tr>
    <th>Pupil</th>
    <th>Parent</th>
    <th>Relationship</th>
    <th>Actions</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['pupil_name'] ?></td>
    <td><?= $row['parent_name'] ?></td>
    <td><?= ucfirst($row['relationship_type']) ?></td>
    <td>
        <a class="btn" 
           href="delete.php?pupil_id=<?= $row['pupil_id'] ?>&parent_id=<?= $row['parent_id'] ?>">
           Delete
        </a>
    </td>
</tr>
<?php } ?>
</table>

<?php require_once "../../views/footer.php"; ?>
