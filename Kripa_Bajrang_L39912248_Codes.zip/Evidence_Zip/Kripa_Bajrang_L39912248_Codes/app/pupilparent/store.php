<?php
require_once "../../config/db.php";

$pupil_id = $_POST['pupil_id'];
$parent_id = $_POST['parent_id'];
$relationship = $_POST['relationship_type'];

/*
 Prevent duplicate link
*/
$check = $conn->query("
    SELECT * FROM pupil_parent 
    WHERE pupil_id = $pupil_id 
      AND parent_id = $parent_id
");

if ($check->num_rows > 0) {
    header("Location: index.php");
    exit;
}

$sql = "
INSERT INTO pupil_parent (pupil_id, parent_id, relationship_type)
VALUES ($pupil_id, $parent_id, '$relationship')
";

$conn->query($sql);

header("Location: index.php");
exit;
