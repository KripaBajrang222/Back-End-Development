<?php
session_start();
require_once "../../config/db.php";
require_once "../../views/header.php";

$pupil_id = (int) $_GET['pupil_id'];
?>

<div class="header">Delete Parent Link</div>

<p>Are you sure you want to remove this parent link?</p>

<a class="btn" href="destroy.php?pupil_id=<?= $pupil_id ?>">
    Yes, Delete
</a>

<a class="btn" href="index.php">
    Cancel
</a>

<?php require_once "../../views/footer.php"; ?>
