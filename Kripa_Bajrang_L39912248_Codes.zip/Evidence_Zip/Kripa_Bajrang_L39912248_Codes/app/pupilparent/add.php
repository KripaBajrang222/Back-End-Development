<?php
require_once "../../config/db.php";
require_once "../../views/header.php";

$pupils  = $conn->query("SELECT id, first_name, last_name FROM pupil ORDER BY first_name");
$parents = $conn->query("SELECT id, first_name, last_name FROM parent ORDER BY first_name");
?>

<div class="header">Link Pupil to Parent</div>

<form action="store.php" method="post">

<label>Pupil</label>
<select name="pupil_id" required>
    <option value="">-- Select Pupil --</option>
    <?php while ($p = $pupils->fetch_assoc()) { ?>
        <option value="<?= $p['id'] ?>">
            <?= $p['first_name'] . " " . $p['last_name'] ?>
        </option>
    <?php } ?>
</select>

<label>Parent</label>
<select name="parent_id" required>
    <option value="">-- Select Parent --</option>
    <?php while ($pa = $parents->fetch_assoc()) { ?>
        <option value="<?= $pa['id'] ?>">
            <?= $pa['first_name'] . " " . $pa['last_name'] ?>
        </option>
    <?php } ?>
</select>

<label>Relationship</label>
<select name="relationship_type" required>
    <option value="mother">Mother</option>
    <option value="father">Father</option>
    <option value="guardian">Guardian</option>
    <option value="other">Other</option>
</select>

<br><br>
<button type="submit">Save</button>
<a class="btn" href="index.php">Cancel</a>

</form>

<?php require_once "../../views/footer.php"; ?>
