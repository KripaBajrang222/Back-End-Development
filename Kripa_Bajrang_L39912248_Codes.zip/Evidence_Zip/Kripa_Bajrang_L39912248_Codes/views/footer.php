<footer class="footer">
    <div class="footer-container">

        <div class="footer-section">
            <h3>St. Alphonsus Primary School</h3>
            <p>
                Building strong foundations for lifelong learning
                through care, respect, and excellence.
            </p>
        </div>

        <div class="footer-section">
            <h3>Contact</h3>
            <p>
                123 Gorton Road<br>
                Manchester, M18 8XX<br>
                info@stalphonsusprimary.uk<br>
                0161 000 0000
            </p>
        </div>

        <div class="footer-section">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href="#">🌐</a>
                <a href="#">📘</a>
                <a href="#">🐦</a>
                <a href="#">📸</a>
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        © <?php echo date("Y"); ?> St. Alphonsus Primary School
    </div>
</footer>
