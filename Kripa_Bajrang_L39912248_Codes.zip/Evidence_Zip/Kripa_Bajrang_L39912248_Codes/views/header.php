<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user'])) {
    header("Location: /school_portal/public/login.php");
    exit;
}
?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="/school_portal/assets/css/style.css">
</head>
<body>

<div class="sidebar">
    <h2>St. Alphonsus<br>School Portal</h2>

    <a href="/school_portal/public/index.php">Dashboard</a>
    <a href="/school_portal/app/teacher/index.php">Teachers</a>
    <a href="/school_portal/app/classes/index.php">Classes</a>
    <a href="/school_portal/app/pupil/index.php">Pupils</a>
    <a href="/school_portal/app/parent/index.php">Parents</a>
    <a href="/school_portal/app/pupilparent/index.php">Pupil–Parent</a>
    <a href="/school_portal/app/attendance/index.php">Attendance</a>
    <a href="/school_portal/app/library_book/index.php">Library</a>
    <a href="/school_portal/public/logout.php">Logout</a>
</div>

<div class="main-content">
